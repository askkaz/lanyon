---
layout: page
title: Contact Me
---

<div id="wufoo-z9vmt2b0e8c1fa">
Fill out my <a href="https://askkaz.wufoo.com/forms/z9vmt2b0e8c1fa">online form</a>.
</div>
<div id="wuf-adv" style="font-family:inherit;font-size: small;color:#a7a7a7;text-align:center;display:block;">HTML Forms powered by <a href="http://www.wufoo.com">Wufoo</a>.</div>
<script type="text/javascript">var z9vmt2b0e8c1fa;(function(d, t) {
var s = d.createElement(t), options = {
'userName':'askkaz',
'formHash':'z9vmt2b0e8c1fa',
'autoResize':true,
'height':'497',
'async':true,
'host':'wufoo.com',
'header':'show',
'ssl':true};
s.src = ('https:' == d.location.protocol ? 'https://' : 'http://') + 'www.wufoo.com/scripts/embed/form.js';
s.onload = s.onreadystatechange = function() {
var rs = this.readyState; if (rs) if (rs != 'complete') if (rs != 'loaded') return;
try { z9vmt2b0e8c1fa = new WufooForm();z9vmt2b0e8c1fa.initialize(options);z9vmt2b0e8c1fa.display(); } catch (e) {}};
var scr = d.getElementsByTagName(t)[0], par = scr.parentNode; par.insertBefore(s, scr);
})(document, 'script');</script>



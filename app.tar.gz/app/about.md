---
layout: page
title: About Me
---

<p class="message">
  I've never done anything like this....
</p>

After college, I spent 10 years in the aerospace and defense industry. This included designing satellite subsystems, managing sensor developments, and trying to make sure everything worked well together. While I seemed to excel at all of this, I realized that I wanted to be spending more time working with software.

With a full time job and a young child, there was limited time left each day for after hours learning and experimentation. With my family's support, I decided to make the jump to a commercial job in software development. Now I get to play with software all day. I haven't looked back.

At work, I use brightscript to write our Roku app. I also use PHP/Laravel to implement the back end functions the app relies on.

As a newcomer to this, right now I'm focusing becoming familiar with a number of different web technologies, before diving in deep with any particular one. With this blog, I plan to write about my cross-cutting learning experiences.

